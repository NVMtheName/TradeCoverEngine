"""
Production-ready configuration for Arbion Trading Platform
Following Heroku Python support best practices
"""
import os
from urllib.parse import urlparse
from heroku_config import HerokuConfig

class Config:
    """Base configuration class with common settings"""
    
    # Flask Core Settings
    SECRET_KEY = os.environ.get('SESSION_SECRET') or os.environ.get('SECRET_KEY') or 'dev-key-change-in-production'
    
    # Database Configuration
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    if SQLALCHEMY_DATABASE_URI and SQLALCHEMY_DATABASE_URI.startswith("postgres://"):
        SQLALCHEMY_DATABASE_URI = SQLALCHEMY_DATABASE_URI.replace("postgres://", "postgresql://", 1)
    
    SQLALCHEMY_ENGINE_OPTIONS = {
        'pool_pre_ping': True,
        'pool_recycle': 300,
        'pool_timeout': 20,
        'max_overflow': 0
    }
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # Session Configuration
    SESSION_TYPE = 'filesystem'
    SESSION_PERMANENT = False
    SESSION_USE_SIGNER = True
    SESSION_KEY_PREFIX = 'arbion:'
    
    # Security Settings
    WTF_CSRF_ENABLED = True
    WTF_CSRF_TIME_LIMIT = 3600
    
    # Application Settings
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file upload
    
    # API Configuration
    OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')
    SCHWAB_API_KEY = os.environ.get('SCHWAB_API_KEY')
    SCHWAB_API_SECRET = os.environ.get('SCHWAB_API_SECRET')
    
    # OAuth Configuration
    GOOGLE_OAUTH_CLIENT_ID = os.environ.get('GOOGLE_OAUTH_CLIENT_ID')
    GOOGLE_OAUTH_CLIENT_SECRET = os.environ.get('GOOGLE_OAUTH_CLIENT_SECRET')
    
    # Domain Configuration for OAuth callbacks
    DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN') or 'localhost:5000'
    
    # Performance Settings
    WEB_CONCURRENCY = int(os.environ.get('WEB_CONCURRENCY', 2))
    
    @staticmethod
    def init_app(app):
        """Initialize app-specific configuration"""
        pass

class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    FLASK_ENV = 'development'
    
    # Development database fallback
    if not Config.SQLALCHEMY_DATABASE_URI:
        SQLALCHEMY_DATABASE_URI = 'sqlite:///dev_arbion.db'
    
    # Development-specific settings
    SQLALCHEMY_ECHO = False  # Set to True for SQL debugging
    WTF_CSRF_ENABLED = False  # Disabled for easier development

class TestingConfig(Config):
    """Testing configuration"""
    TESTING = True
    FLASK_ENV = 'testing'
    WTF_CSRF_ENABLED = False
    
    # Use in-memory database for testing
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'
    
    # Disable external API calls during testing
    OPENAI_API_KEY = 'test-key'
    SCHWAB_API_KEY = 'test-key'
    SCHWAB_API_SECRET = 'test-secret'

class ProductionConfig(Config):
    """Production configuration for Heroku deployment"""
    DEBUG = False
    FLASK_ENV = 'production'
    
    # Production security settings
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Force HTTPS in production
    PREFERRED_URL_SCHEME = 'https'
    
    # Production database settings
    SQLALCHEMY_ENGINE_OPTIONS = {
        **Config.SQLALCHEMY_ENGINE_OPTIONS,
        'pool_size': int(os.environ.get('DB_POOL_SIZE', 10)),
        'max_overflow': int(os.environ.get('DB_MAX_OVERFLOW', 20))
    }
    
    @staticmethod
    def init_app(app):
        """Production-specific initialization"""
        Config.init_app(app)
        
        # Log to stderr in production
        import logging
        from logging import StreamHandler
        file_handler = StreamHandler()
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)

class HerokuConfig(ProductionConfig):
    """Heroku-specific configuration"""
    
    # Heroku-specific optimizations
    WEB_CONCURRENCY = int(os.environ.get('WEB_CONCURRENCY', 2))
    PYTHON_MAX_THREADS = int(os.environ.get('PYTHON_MAX_THREADS', 1))
    
    # Enhanced database settings for Heroku
    SQLALCHEMY_ENGINE_OPTIONS = {
        **ProductionConfig.SQLALCHEMY_ENGINE_OPTIONS,
        'pool_size': int(os.environ.get('DB_POOL_SIZE', 10)),
        'max_overflow': int(os.environ.get('DB_MAX_OVERFLOW', 20)),
        'pool_timeout': int(os.environ.get('DB_POOL_TIMEOUT', 20)),
        'pool_recycle': int(os.environ.get('DB_POOL_RECYCLE', 300))
    }
    
    @classmethod
    def init_app(cls, app):
        """Heroku-specific initialization with comprehensive monitoring"""
        ProductionConfig.init_app(app)
        
        # Handle proxy fix for Heroku load balancers
        from werkzeug.middleware.proxy_fix import ProxyFix
        app.wsgi_app = ProxyFix(app.wsgi_app, x_proto=1, x_host=1)
        
        # Configure Heroku logging
        import logging
        stream_handler = logging.StreamHandler()
        stream_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s %(levelname)s [%(name)s] %(message)s'
        )
        stream_handler.setFormatter(formatter)
        app.logger.addHandler(stream_handler)
        app.logger.setLevel(logging.INFO)
        
        # Set up New Relic monitoring if available
        if os.environ.get('NEW_RELIC_LICENSE_KEY'):
            try:
                import newrelic.agent
                newrelic.agent.initialize('newrelic.ini')
                app.logger.info('New Relic monitoring initialized')
            except ImportError:
                app.logger.warning('New Relic agent not available')
        
        # Configure security headers
        @app.after_request
        def set_security_headers(response):
            response.headers['X-Content-Type-Options'] = 'nosniff'
            response.headers['X-Frame-Options'] = 'DENY'
            response.headers['X-XSS-Protection'] = '1; mode=block'
            response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
            return response
        
        app.logger.info('Heroku configuration initialized successfully')

# Configuration selection
config = {
    'development': DevelopmentConfig,
    'testing': TestingConfig,
    'production': ProductionConfig,
    'heroku': HerokuConfig,
    'default': DevelopmentConfig
}

def get_config():
    """Get configuration based on environment"""
    env = os.environ.get('FLASK_ENV', 'development').lower()
    
    # Heroku detection
    if os.environ.get('DYNO'):
        return config['heroku']
    
    return config.get(env, config['default'])