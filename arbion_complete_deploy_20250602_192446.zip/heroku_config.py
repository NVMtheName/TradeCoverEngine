"""
Heroku-specific configuration and utilities
Following Heroku Python support best practices
"""
import os
import logging

class HerokuConfig:
    """Heroku-specific configuration settings"""
    
    # Dyno management
    WEB_CONCURRENCY = int(os.environ.get('WEB_CONCURRENCY', 2))
    PYTHON_MAX_THREADS = int(os.environ.get('PYTHON_MAX_THREADS', 1))
    
    # Logging configuration
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO').upper()
    
    # Database configuration
    DATABASE_CONNECTION_POOL_SIZE = int(os.environ.get('DB_POOL_SIZE', 10))
    DATABASE_CONNECTION_POOL_TIMEOUT = int(os.environ.get('DB_POOL_TIMEOUT', 20))
    DATABASE_CONNECTION_POOL_RECYCLE = int(os.environ.get('DB_POOL_RECYCLE', 300))
    
    # Redis configuration
    REDIS_URL = os.environ.get('REDIS_URL')
    REDIS_SSL_CERT_REQS = None  # Heroku Redis requires this
    
    # Application performance monitoring
    NEW_RELIC_LICENSE_KEY = os.environ.get('NEW_RELIC_LICENSE_KEY')
    
    # Security headers
    FORCE_HTTPS = True
    SECURE_SSL_REDIRECT = True
    SESSION_COOKIE_SECURE = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'
    
    # Request handling
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB
    REQUEST_TIMEOUT = 30
    
    @staticmethod
    def configure_logging():
        """Configure logging for Heroku environment"""
        logging.basicConfig(
            level=getattr(logging, HerokuConfig.LOG_LEVEL),
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[logging.StreamHandler()]
        )
        
        # Suppress verbose logs in production
        if HerokuConfig.LOG_LEVEL != 'DEBUG':
            logging.getLogger('werkzeug').setLevel(logging.WARNING)
            logging.getLogger('urllib3').setLevel(logging.WARNING)
    
    @staticmethod
    def get_database_config():
        """Get optimized database configuration for Heroku"""
        return {
            'pool_size': HerokuConfig.DATABASE_CONNECTION_POOL_SIZE,
            'pool_timeout': HerokuConfig.DATABASE_CONNECTION_POOL_TIMEOUT,
            'pool_recycle': HerokuConfig.DATABASE_CONNECTION_POOL_RECYCLE,
            'pool_pre_ping': True,
            'max_overflow': 0,
            'echo': False
        }
    
    @staticmethod
    def is_heroku_environment():
        """Check if running on Heroku"""
        return 'DYNO' in os.environ