# Trading Bot - Heroku Deployment

This package contains a ready-to-deploy version of the Trading Bot application for Heroku.

## Super Easy Deployment (No Python Experience Needed)

1. **Create a Heroku Account**:
   Go to https://signup.heroku.com/ and create a free account if you don't already have one.

2. **Install the Heroku CLI**:
   Download and install from https://devcenter.heroku.com/articles/heroku-cli

3. **Extract this ZIP file** to a folder on your computer.

4. **Open Command Prompt or Terminal**:
   - On Windows: Press Win+R, type "cmd" and press Enter
   - On Mac: Open Terminal from Applications > Utilities

5. **Navigate to the extracted folder**:
   ```
   cd path/to/extracted/folder
   ```

6. **Run the deployment helper script**:
   ```
   deploy_to_heroku.bat    (on Windows)
   ```
   or
   ```
   ./deploy_to_heroku.sh   (on Mac/Linux)
   ```

7. **Follow the prompts** in the script - it will:
   - Log you into Heroku
   - Create your app
   - Set up the database
   - Deploy the application
   - Run database migrations
   - Open your app in a browser

## Configuring API Keys (After Deployment)

After your app is running, you'll need to set up your API keys:
```
heroku config:set SCHWAB_API_KEY=your_key_here
heroku config:set SCHWAB_API_SECRET=your_secret_here
heroku config:set OPENAI_API_KEY=your_openai_key_here
```

## Troubleshooting

- **Database issues**: 
  Run `heroku pg:info` to check database status.
  
- **Application errors**: 
  Check logs with `heroku logs --tail`

- **Deployment failures**: 
  Ensure you have the correct buildpacks with `heroku buildpacks`
  
## Additional Resources

- Heroku Python Support: https://devcenter.heroku.com/articles/python-support
- Heroku PostgreSQL: https://devcenter.heroku.com/articles/heroku-postgresql
