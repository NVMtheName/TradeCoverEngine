#!/bin/bash
# Heroku Deployment Script for Arbion Trading Platform

echo "🚀 Deploying Arbion Trading Platform to Heroku"

# Check if Heroku CLI is installed
if ! command -v heroku &> /dev/null; then
    echo "❌ Heroku CLI not found. Please install it first:"
    echo "https://devcenter.heroku.com/articles/heroku-cli"
    exit 1
fi

# Login to Heroku
echo "📝 Please login to Heroku..."
heroku login

# Create Heroku app
read -p "Enter your Heroku app name (e.g., my-arbion-app): " APP_NAME
heroku create $APP_NAME

# Add PostgreSQL addon
echo "🗄️ Adding PostgreSQL database..."
heroku addons:create heroku-postgresql:mini --app $APP_NAME

# Set environment variables
echo "🔧 Setting environment variables..."
heroku config:set FLASK_ENV=production --app $APP_NAME
heroku config:set WEB_CONCURRENCY=2 --app $APP_NAME
heroku config:set PYTHON_MAX_THREADS=1 --app $APP_NAME

# Generate secret keys
SECRET_KEY=$(openssl rand -base64 32)
SESSION_SECRET=$(openssl rand -base64 32)
heroku config:set SECRET_KEY="$SECRET_KEY" --app $APP_NAME
heroku config:set SESSION_SECRET="$SESSION_SECRET" --app $APP_NAME

# Optional: Set API keys
read -p "Enter OpenAI API key (optional, press Enter to skip): " OPENAI_KEY
if [ ! -z "$OPENAI_KEY" ]; then
    heroku config:set OPENAI_API_KEY="$OPENAI_KEY" --app $APP_NAME
fi

read -p "Enter Schwab API key (optional, press Enter to skip): " SCHWAB_KEY
if [ ! -z "$SCHWAB_KEY" ]; then
    heroku config:set SCHWAB_API_KEY="$SCHWAB_KEY" --app $APP_NAME
fi

read -p "Enter Schwab API secret (optional, press Enter to skip): " SCHWAB_SECRET
if [ ! -z "$SCHWAB_SECRET" ]; then
    heroku config:set SCHWAB_API_SECRET="$SCHWAB_SECRET" --app $APP_NAME
fi

# Initialize git and deploy
echo "📦 Initializing git repository..."
git init
git add .
git commit -m "Initial deployment of Arbion Trading Platform"

echo "🚀 Adding Heroku remote and deploying..."
heroku git:remote -a $APP_NAME
git push heroku main

echo "✅ Deployment complete!"
echo "🌐 Your app is available at: https://$APP_NAME.herokuapp.com"
echo "👤 Admin login: username='admin', password='admin123'"
echo ""
echo "📋 Next steps:"
echo "1. Visit your app and login as admin"
echo "2. Go to Settings to configure Schwab API credentials"
echo "3. Register OAuth callback URL with Schwab Developer Portal"
