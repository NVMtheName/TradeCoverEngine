"""
Comprehensive Schwab API Connector using schwab-py library
Implements all available features from the official Schwab Python SDK
"""

import os
import json
import logging
import asyncio
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Any, Union
from pathlib import Path

# Import schwab-py library components
import schwab
from schwab.auth import client_from_login_flow, client_from_token_file
from schwab.client import Client
from schwab.streaming import StreamClient

logger = logging.getLogger(__name__)

class SchwabConnector:
    """
    Complete Schwab API integration using schwab-py library
    Supports all available endpoints and features
    """
    
    def __init__(self, api_key: str, api_secret: str, callback_url: str, token_path: str = None):
        """
        Initialize Schwab connector with API credentials
        
        Args:
            api_key: Schwab API key
            api_secret: Schwab API secret  
            callback_url: OAuth callback URL
            token_path: Path to store/load tokens
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.callback_url = callback_url
        self.token_path = token_path or '/tmp/schwab_tokens.json'
        self.client: Optional[Client] = None
        self.stream_client: Optional[StreamClient] = None
        
        # Initialize client if tokens exist
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize Schwab client from existing tokens or start OAuth flow"""
        try:
            if os.path.exists(self.token_path):
                logger.info("Loading Schwab client from existing tokens")
                self.client = client_from_token_file(
                    token_path=self.token_path,
                    api_key=self.api_key,
                    app_secret=self.api_secret
                )
                logger.info("Schwab client initialized successfully from tokens")
            else:
                logger.info("No existing tokens found, OAuth flow required")
        except Exception as e:
            logger.error(f"Error initializing Schwab client: {str(e)}")
    
    def start_oauth_flow(self) -> str:
        """
        Start OAuth authentication flow
        Returns the authorization URL for user authentication
        """
        try:
            # Create OAuth authorization URL
            auth_url = schwab.auth.client_from_login_flow(
                api_key=self.api_key,
                app_secret=self.api_secret,
                callback_url=self.callback_url,
                token_path=self.token_path
            )
            
            logger.info(f"OAuth flow started, authorization URL: {auth_url}")
            return auth_url
            
        except Exception as e:
            logger.error(f"Error starting OAuth flow: {str(e)}")
            raise
    
    def complete_oauth_flow(self, callback_url_with_code: str):
        """
        Complete OAuth flow with the callback URL containing authorization code
        
        Args:
            callback_url_with_code: Full callback URL with authorization code
        """
        try:
            self.client = client_from_login_flow(
                api_key=self.api_key,
                app_secret=self.api_secret,
                callback_url=callback_url_with_code,
                token_path=self.token_path
            )
            logger.info("OAuth flow completed successfully")
            return True
        except Exception as e:
            logger.error(f"Error completing OAuth flow: {str(e)}")
            return False
    
    def is_authenticated(self) -> bool:
        """Check if client is authenticated and ready"""
        return self.client is not None
    
    # =================================================================
    # ACCOUNT ENDPOINTS
    # =================================================================
    
    def get_account_numbers(self) -> List[Dict]:
        """Get all account numbers linked to the user"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_account_numbers()
            return response.json()
        except Exception as e:
            logger.error(f"Error getting account numbers: {str(e)}")
            raise
    
    def get_account_info(self, account_hash: str, fields: str = None) -> Dict:
        """
        Get account information
        
        Args:
            account_hash: Account hash identifier
            fields: Optional fields to include (positions, orders)
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_account(account_hash, fields=fields)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting account info: {str(e)}")
            raise
    
    def get_all_accounts(self, fields: str = None) -> List[Dict]:
        """Get information for all accounts"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_accounts(fields=fields)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting all accounts: {str(e)}")
            raise
    
    # =================================================================
    # ORDERS ENDPOINTS
    # =================================================================
    
    def get_orders(self, account_hash: str, from_entered_time: datetime = None, 
                   to_entered_time: datetime = None, max_results: int = 3000,
                   status: str = None) -> List[Dict]:
        """
        Get orders for an account
        
        Args:
            account_hash: Account hash
            from_entered_time: Start date for orders
            to_entered_time: End date for orders
            max_results: Maximum number of results
            status: Order status filter
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_orders_for_account(
                account_hash=account_hash,
                from_entered_time=from_entered_time,
                to_entered_time=to_entered_time,
                max_results=max_results,
                status=status
            )
            return response.json()
        except Exception as e:
            logger.error(f"Error getting orders: {str(e)}")
            raise
    
    def get_all_orders(self, from_entered_time: datetime = None,
                       to_entered_time: datetime = None, max_results: int = 3000,
                       status: str = None) -> List[Dict]:
        """Get orders for all accounts"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_orders_for_all_accounts(
                from_entered_time=from_entered_time,
                to_entered_time=to_entered_time,
                max_results=max_results,
                status=status
            )
            return response.json()
        except Exception as e:
            logger.error(f"Error getting all orders: {str(e)}")
            raise
    
    def get_order(self, account_hash: str, order_id: str) -> Dict:
        """Get specific order by ID"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_order(account_hash, order_id)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting order {order_id}: {str(e)}")
            raise
    
    def place_order(self, account_hash: str, order_spec: Dict) -> Dict:
        """
        Place an order
        
        Args:
            account_hash: Account hash
            order_spec: Order specification dictionary
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.place_order(account_hash, order_spec)
            return {
                'success': True,
                'status_code': response.status_code,
                'headers': dict(response.headers),
                'order_id': response.headers.get('location', '').split('/')[-1]
            }
        except Exception as e:
            logger.error(f"Error placing order: {str(e)}")
            raise
    
    def cancel_order(self, account_hash: str, order_id: str) -> Dict:
        """Cancel an existing order"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.cancel_order(account_hash, order_id)
            return {
                'success': True,
                'status_code': response.status_code
            }
        except Exception as e:
            logger.error(f"Error canceling order {order_id}: {str(e)}")
            raise
    
    def replace_order(self, account_hash: str, order_id: str, order_spec: Dict) -> Dict:
        """Replace an existing order"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.replace_order(account_hash, order_id, order_spec)
            return {
                'success': True,
                'status_code': response.status_code,
                'headers': dict(response.headers)
            }
        except Exception as e:
            logger.error(f"Error replacing order {order_id}: {str(e)}")
            raise
    
    # =================================================================
    # MARKET DATA ENDPOINTS
    # =================================================================
    
    def get_quotes(self, symbols: Union[str, List[str]], fields: str = None) -> Dict:
        """
        Get quotes for one or more symbols
        
        Args:
            symbols: Single symbol or list of symbols
            fields: Optional fields to include
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            if isinstance(symbols, str):
                response = self.client.get_quote(symbols, fields=fields)
            else:
                response = self.client.get_quotes(symbols, fields=fields)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting quotes for {symbols}: {str(e)}")
            raise
    
    def get_price_history(self, symbol: str, period_type: str = 'day',
                         period: int = 10, frequency_type: str = 'minute',
                         frequency: int = 1, start_date: datetime = None,
                         end_date: datetime = None, need_extended_hours_data: bool = True,
                         need_previous_close: bool = True) -> Dict:
        """
        Get price history for a symbol
        
        Args:
            symbol: Stock symbol
            period_type: Type of period (day, month, year, ytd)
            period: Number of periods
            frequency_type: Frequency type (minute, daily, weekly, monthly)
            frequency: Frequency value
            start_date: Start date for custom range
            end_date: End date for custom range
            need_extended_hours_data: Include extended hours
            need_previous_close: Include previous close
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_price_history(
                symbol=symbol,
                period_type=period_type,
                period=period,
                frequency_type=frequency_type,
                frequency=frequency,
                start_date=start_date,
                end_date=end_date,
                need_extended_hours_data=need_extended_hours_data,
                need_previous_close=need_previous_close
            )
            return response.json()
        except Exception as e:
            logger.error(f"Error getting price history for {symbol}: {str(e)}")
            raise
    
    def get_option_chain(self, symbol: str, contract_type: str = 'ALL',
                        strike_count: int = 10, include_quotes: bool = False,
                        strategy: str = 'SINGLE', interval: float = None,
                        strike: float = None, range_param: str = 'ALL',
                        from_date: datetime = None, to_date: datetime = None,
                        volatility: float = None, underlying_price: float = None,
                        interest_rate: float = None, days_to_expiration: int = None,
                        exp_month: str = 'ALL', option_type: str = 'ALL') -> Dict:
        """
        Get option chain for a symbol
        
        Args:
            symbol: Underlying symbol
            contract_type: Contract type (CALL, PUT, ALL)
            strike_count: Number of strikes to return
            include_quotes: Include quotes
            strategy: Option strategy
            interval: Strike price interval
            strike: Specific strike price
            range_param: Strike range (ITM, NTM, OTM, SAK, SBK, SNK, ALL)
            from_date: Start date for expiration range
            to_date: End date for expiration range
            volatility: Volatility to use in calculations
            underlying_price: Underlying price for calculations
            interest_rate: Interest rate for calculations
            days_to_expiration: Days to expiration
            exp_month: Expiration month (ALL, JAN, FEB, etc.)
            option_type: Option type (S, NS, ALL)
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_option_chain(
                symbol=symbol,
                contract_type=contract_type,
                strike_count=strike_count,
                include_quotes=include_quotes,
                strategy=strategy,
                interval=interval,
                strike=strike,
                range=range_param,
                from_date=from_date,
                to_date=to_date,
                volatility=volatility,
                underlying_price=underlying_price,
                interest_rate=interest_rate,
                days_to_expiration=days_to_expiration,
                exp_month=exp_month,
                option_type=option_type
            )
            return response.json()
        except Exception as e:
            logger.error(f"Error getting option chain for {symbol}: {str(e)}")
            raise
    
    def get_option_expiration_chain(self, symbol: str) -> Dict:
        """Get option expiration dates for a symbol"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_option_expiration_chain(symbol)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting option expiration chain for {symbol}: {str(e)}")
            raise
    
    # =================================================================
    # INSTRUMENTS ENDPOINTS
    # =================================================================
    
    def search_instruments(self, symbol: str, projection: str = 'symbol-search') -> Dict:
        """
        Search for instruments
        
        Args:
            symbol: Symbol to search for
            projection: Search type (symbol-search, symbol-regex, desc-search, desc-regex, fundamental)
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.search_instruments(symbol, projection)
            return response.json()
        except Exception as e:
            logger.error(f"Error searching instruments for {symbol}: {str(e)}")
            raise
    
    def get_instrument(self, cusip: str) -> Dict:
        """Get instrument by CUSIP"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_instrument(cusip)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting instrument {cusip}: {str(e)}")
            raise
    
    # =================================================================
    # MARKET HOURS ENDPOINTS
    # =================================================================
    
    def get_market_hours(self, markets: Union[str, List[str]], 
                        date: datetime = None) -> Dict:
        """
        Get market hours for specified markets
        
        Args:
            markets: Market or list of markets (EQUITY, OPTION, BOND, etc.)
            date: Date to get hours for (defaults to today)
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            if isinstance(markets, str):
                response = self.client.get_market_hour(markets, date)
            else:
                response = self.client.get_market_hours(markets, date)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting market hours for {markets}: {str(e)}")
            raise
    
    # =================================================================
    # MOVERS ENDPOINTS
    # =================================================================
    
    def get_movers(self, index: str, direction: str = None, change: str = None) -> Dict:
        """
        Get market movers
        
        Args:
            index: Market index ($DJI, $COMPX, $SPX)
            direction: Direction filter (up, down)
            change: Change type (value, percent)
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_movers(index, direction, change)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting movers for {index}: {str(e)}")
            raise
    
    # =================================================================
    # TRANSACTIONS ENDPOINTS
    # =================================================================
    
    def get_transactions(self, account_hash: str, transaction_type: str = None,
                        symbol: str = None, start_date: datetime = None,
                        end_date: datetime = None) -> List[Dict]:
        """
        Get account transactions
        
        Args:
            account_hash: Account hash
            transaction_type: Transaction type filter
            symbol: Symbol filter
            start_date: Start date
            end_date: End date
        """
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_transactions(
                account_hash=account_hash,
                transaction_type=transaction_type,
                symbol=symbol,
                start_date=start_date,
                end_date=end_date
            )
            return response.json()
        except Exception as e:
            logger.error(f"Error getting transactions: {str(e)}")
            raise
    
    def get_transaction(self, account_hash: str, transaction_id: str) -> Dict:
        """Get specific transaction by ID"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_transaction(account_hash, transaction_id)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting transaction {transaction_id}: {str(e)}")
            raise
    
    # =================================================================
    # USER PREFERENCES ENDPOINTS
    # =================================================================
    
    def get_preferences(self, account_hash: str) -> Dict:
        """Get user preferences for account"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_preferences(account_hash)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting preferences: {str(e)}")
            raise
    
    def update_preferences(self, account_hash: str, preferences: Dict) -> Dict:
        """Update user preferences"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.update_preferences(account_hash, preferences)
            return {
                'success': True,
                'status_code': response.status_code
            }
        except Exception as e:
            logger.error(f"Error updating preferences: {str(e)}")
            raise
    
    # =================================================================
    # WATCHLISTS ENDPOINTS
    # =================================================================
    
    def get_watchlists(self, account_hash: str) -> List[Dict]:
        """Get all watchlists for account"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_watchlists_for_account(account_hash)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting watchlists: {str(e)}")
            raise
    
    def get_watchlist(self, account_hash: str, watchlist_id: str) -> Dict:
        """Get specific watchlist"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.get_watchlist(account_hash, watchlist_id)
            return response.json()
        except Exception as e:
            logger.error(f"Error getting watchlist {watchlist_id}: {str(e)}")
            raise
    
    def create_watchlist(self, account_hash: str, watchlist_spec: Dict) -> Dict:
        """Create new watchlist"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.create_watchlist(account_hash, watchlist_spec)
            return {
                'success': True,
                'status_code': response.status_code,
                'watchlist_id': response.headers.get('location', '').split('/')[-1]
            }
        except Exception as e:
            logger.error(f"Error creating watchlist: {str(e)}")
            raise
    
    def delete_watchlist(self, account_hash: str, watchlist_id: str) -> Dict:
        """Delete watchlist"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.delete_watchlist(account_hash, watchlist_id)
            return {
                'success': True,
                'status_code': response.status_code
            }
        except Exception as e:
            logger.error(f"Error deleting watchlist {watchlist_id}: {str(e)}")
            raise
    
    def update_watchlist(self, account_hash: str, watchlist_id: str, 
                        watchlist_spec: Dict) -> Dict:
        """Update existing watchlist"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            response = self.client.update_watchlist(account_hash, watchlist_id, watchlist_spec)
            return {
                'success': True,
                'status_code': response.status_code
            }
        except Exception as e:
            logger.error(f"Error updating watchlist {watchlist_id}: {str(e)}")
            raise
    
    # =================================================================
    # STREAMING DATA
    # =================================================================
    
    def initialize_streaming(self, account_hash: str) -> bool:
        """Initialize streaming client"""
        if not self.client:
            raise Exception("Client not authenticated")
        
        try:
            self.stream_client = StreamClient(self.client, account_id=account_hash)
            logger.info("Streaming client initialized successfully")
            return True
        except Exception as e:
            logger.error(f"Error initializing streaming client: {str(e)}")
            return False
    
    async def stream_level_one_equity(self, symbols: List[str], fields: List[str] = None):
        """Stream level one equity data"""
        if not self.stream_client:
            raise Exception("Streaming client not initialized")
        
        try:
            await self.stream_client.level_one_equity_subs(symbols, fields)
            async for message in self.stream_client.stream():
                yield message
        except Exception as e:
            logger.error(f"Error in equity streaming: {str(e)}")
            raise
    
    async def stream_level_one_option(self, symbols: List[str], fields: List[str] = None):
        """Stream level one option data"""
        if not self.stream_client:
            raise Exception("Streaming client not initialized")
        
        try:
            await self.stream_client.level_one_option_subs(symbols, fields)
            async for message in self.stream_client.stream():
                yield message
        except Exception as e:
            logger.error(f"Error in option streaming: {str(e)}")
            raise
    
    # =================================================================
    # UTILITY METHODS
    # =================================================================
    
    def get_account_hash(self, account_number: str) -> str:
        """Get account hash from account number"""
        try:
            accounts = self.get_account_numbers()
            for account in accounts:
                if account.get('accountNumber') == account_number:
                    return account.get('hashValue')
            raise Exception(f"Account number {account_number} not found")
        except Exception as e:
            logger.error(f"Error getting account hash: {str(e)}")
            raise
    
    def get_primary_account(self) -> Dict:
        """Get the primary account information"""
        try:
            accounts = self.get_account_numbers()
            if not accounts:
                raise Exception("No accounts found")
            
            # Return the first account as primary
            primary_account = accounts[0]
            account_hash = primary_account.get('hashValue')
            
            # Get detailed account info
            return self.get_account_info(account_hash, fields='positions,orders')
        except Exception as e:
            logger.error(f"Error getting primary account: {str(e)}")
            raise
    
    def format_order_for_schwab(self, order_data: Dict) -> Dict:
        """
        Format order data for Schwab API
        
        Args:
            order_data: Order data in standard format
            
        Returns:
            Schwab-formatted order specification
        """
        try:
            # Convert standard order format to Schwab format
            schwab_order = {
                "orderType": order_data.get("order_type", "MARKET").upper(),
                "session": order_data.get("session", "NORMAL").upper(),
                "duration": order_data.get("duration", "DAY").upper(),
                "orderStrategyType": order_data.get("strategy_type", "SINGLE").upper(),
                "orderLegCollection": []
            }
            
            # Add price for limit orders
            if schwab_order["orderType"] == "LIMIT":
                schwab_order["price"] = str(order_data.get("price", 0))
            
            # Add stop price for stop orders
            if schwab_order["orderType"] in ["STOP", "STOP_LIMIT"]:
                schwab_order["stopPrice"] = str(order_data.get("stop_price", 0))
            
            # Add order leg
            leg = {
                "instruction": order_data.get("instruction", "BUY").upper(),
                "quantity": int(order_data.get("quantity", 1)),
                "instrument": {
                    "symbol": order_data.get("symbol", "").upper(),
                    "assetType": order_data.get("asset_type", "EQUITY").upper()
                }
            }
            
            schwab_order["orderLegCollection"].append(leg)
            
            return schwab_order
            
        except Exception as e:
            logger.error(f"Error formatting order for Schwab: {str(e)}")
            raise
    
    def close_connection(self):
        """Close connections and cleanup"""
        try:
            if self.stream_client:
                # Note: Actual closing would be handled by the schwab-py library
                self.stream_client = None
            
            if self.client:
                # Note: Client cleanup would be handled by the schwab-py library
                pass
                
            logger.info("Schwab connections closed successfully")
        except Exception as e:
            logger.error(f"Error closing connections: {str(e)}")

def create_connector_from_settings(settings):
    """
    Create SchwabConnector from settings dictionary
    
    Args:
        settings: Settings dictionary containing API credentials
        
    Returns:
        SchwabConnector instance or None if credentials missing
    """
    try:
        # Handle both dict and object settings
        if hasattr(settings, 'api_key'):
            # Settings object
            api_key = settings.api_key or os.environ.get('SCHWAB_API_KEY')
            api_secret = settings.api_secret or os.environ.get('SCHWAB_API_SECRET')
        else:
            # Dictionary settings
            api_key = settings.get('api_key') or settings.get('schwab_api_key') or os.environ.get('SCHWAB_API_KEY')
            api_secret = settings.get('api_secret') or settings.get('schwab_api_secret') or os.environ.get('SCHWAB_API_SECRET')
        
        if not api_key or not api_secret:
            logger.warning("Schwab API credentials not found in settings")
            return None
        
        # Default callback URL
        callback_url = 'https://localhost:5000/schwab-callback'
        if hasattr(settings, 'schwab_callback_url'):
            callback_url = settings.schwab_callback_url or callback_url
        elif isinstance(settings, dict):
            callback_url = settings.get('schwab_callback_url', callback_url)
        
        # Default token path
        token_path = '/tmp/schwab_tokens.json'
        if hasattr(settings, 'schwab_token_path'):
            token_path = settings.schwab_token_path or token_path
        elif isinstance(settings, dict):
            token_path = settings.get('schwab_token_path', token_path)
        
        connector = SchwabConnector(api_key, api_secret, callback_url, token_path)
        logger.info("Schwab connector created from settings")
        return connector
        
    except Exception as e:
        logger.error(f"Error creating Schwab connector from settings: {str(e)}")
        return None