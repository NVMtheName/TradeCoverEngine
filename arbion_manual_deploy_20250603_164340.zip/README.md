# Arbion Trading Platform - Heroku Deployment

## Overview
This is the complete Arbion Trading Platform with comprehensive schwab-py library integration, featuring:

- **Popup OAuth Authentication**: Seamless Schwab account linking without redirects
- **Complete schwab-py Integration**: All features including account management, market data, options chains, streaming data, watchlist management, and transaction history
- **AI-Powered Analysis**: GPT-4o integration for intelligent trading insights
- **Multi-User Support**: Role-based admin controls and user management
- **Custom Domain Ready**: Configured for arbion.ai with security headers
- **Production-Ready**: Optimized for Heroku deployment with PostgreSQL

## Quick Deployment

### Option 1: Automated Script
```bash
chmod +x deploy.sh
./deploy.sh
```

### Option 2: Manual Steps

1. **Install Heroku CLI**
   ```bash
   # macOS
   brew tap heroku/brew && brew install heroku
   
   # Ubuntu/Debian
   curl https://cli-assets.heroku.com/install-ubuntu.sh | sh
   
   # Windows
   # Download from https://devcenter.heroku.com/articles/heroku-cli
   ```

2. **Login to Heroku**
   ```bash
   heroku login
   ```

3. **Create Heroku App**
   ```bash
   heroku create your-app-name
   ```

4. **Add PostgreSQL**
   ```bash
   heroku addons:create heroku-postgresql:mini --app your-app-name
   ```

5. **Set Environment Variables**
   ```bash
   heroku config:set FLASK_ENV=production --app your-app-name
   heroku config:set SECRET_KEY=$(openssl rand -base64 32) --app your-app-name
   heroku config:set SESSION_SECRET=$(openssl rand -base64 32) --app your-app-name
   
   # Optional: Add API keys
   heroku config:set OPENAI_API_KEY=your_openai_key --app your-app-name
   heroku config:set SCHWAB_API_KEY=your_schwab_client_id --app your-app-name
   heroku config:set SCHWAB_API_SECRET=your_schwab_client_secret --app your-app-name
   ```

6. **Deploy**
   ```bash
   git init
   git add .
   git commit -m "Deploy Arbion Trading Platform"
   heroku git:remote -a your-app-name
   git push heroku main
   ```

## Post-Deployment Setup

### 1. Admin Access
- URL: `https://your-app-name.herokuapp.com`
- Username: `admin`
- Password: `admin123`

### 2. Schwab API Configuration
1. Login as admin
2. Go to Settings page
3. Enter your Schwab API credentials:
   - API Key (Client ID)
   - API Secret (Client Secret)
4. Click "Connect to Schwab" to test the popup OAuth flow

### 3. Schwab Developer Portal Setup
Register your OAuth callback URL in the Schwab Developer Portal:
- Callback URL: `https://your-app-name.herokuapp.com/oauth/callback`
- Scope: `trading`

## Features Demonstrated

### Schwab-py Library Integration
- **Account Management**: Real-time account data and positions
- **Market Data**: Live quotes, historical data, and market insights
- **Options Chains**: Complete options data with Greeks and analytics
- **Order Management**: Place, modify, and cancel orders
- **Streaming Data**: Real-time market data streams
- **Watchlist Management**: Create and manage multiple watchlists
- **Transaction History**: Complete trading history and performance analytics

### AI-Powered Features
- **Stock Analysis**: GPT-4o powered fundamental and technical analysis
- **Strategy Recommendations**: AI-driven trading strategy suggestions
- **Risk Assessment**: Intelligent risk analysis and position sizing
- **Market Insights**: Real-time market commentary and trend analysis

### Trading Strategies
- **Covered Calls**: Automated covered call writing strategies
- **Put Credit Spreads**: Credit spread strategy implementation
- **Iron Condors**: Multi-leg options strategies
- **Wheel Strategy**: Cash-secured puts and covered calls
- **Collar Strategy**: Protective collar implementations

### Security & Performance
- **HTTPS Enforcement**: SSL/TLS security throughout
- **CSRF Protection**: Cross-site request forgery protection
- **Session Management**: Secure session handling
- **Database Connection Pooling**: Optimized PostgreSQL connections
- **Error Handling**: Comprehensive error handling and logging

## Architecture

```
├── app.py                 # Main Flask application
├── main.py               # WSGI entry point
├── models.py             # Database models
├── forms.py              # WTForms definitions
├── config.py             # Configuration management
├── init_production_db.py # Database initialization
├── trading_bot/          # Core trading functionality
│   ├── schwab_connector.py    # Comprehensive schwab-py integration
│   ├── api_connector.py       # Multi-provider API abstraction
│   ├── ai_advisor.py          # OpenAI GPT integration
│   ├── strategies.py          # Trading strategy implementations
│   ├── auto_trader.py         # Automated trading engine
│   └── stock_analyzer.py      # Technical analysis tools
├── templates/            # Jinja2 templates
├── static/              # CSS, JS, images
├── Procfile             # Heroku process configuration
├── requirements.txt     # Python dependencies
└── runtime.txt          # Python version specification
```

## Environment Variables

### Required
- `FLASK_ENV`: Set to 'production'
- `SECRET_KEY`: Flask secret key for sessions
- `SESSION_SECRET`: Session encryption key
- `DATABASE_URL`: PostgreSQL connection string (auto-set by Heroku)

### Optional
- `OPENAI_API_KEY`: For AI-powered features
- `SCHWAB_API_KEY`: Schwab OAuth client ID
- `SCHWAB_API_SECRET`: Schwab OAuth client secret
- `WEB_CONCURRENCY`: Number of worker processes (default: 2)
- `PYTHON_MAX_THREADS`: Threads per worker (default: 1)

## Custom Domain Setup (Optional)

To use your custom domain (e.g., arbion.ai):

1. **Add domain to Heroku**
   ```bash
   heroku domains:add arbion.ai --app your-app-name
   heroku domains:add www.arbion.ai --app your-app-name
   ```

2. **Configure DNS**
   - Point your domain's CNAME to the Heroku DNS target
   - The platform includes automatic HTTPS redirection and security headers

3. **SSL Certificate**
   ```bash
   heroku certs:auto:enable --app your-app-name
   ```

## Troubleshooting

### Common Issues

1. **Build Failures**
   - Check that all files are included in git: `git status`
   - Verify requirements.txt is valid: `pip install -r requirements.txt`

2. **Database Issues**
   - Check PostgreSQL addon: `heroku addons --app your-app-name`
   - View database logs: `heroku logs --tail --app your-app-name`

3. **OAuth Issues**
   - Verify callback URL in Schwab Developer Portal
   - Check API credentials in Heroku config: `heroku config --app your-app-name`

### Support Commands

```bash
# View logs
heroku logs --tail --app your-app-name

# Check app status
heroku ps --app your-app-name

# Run database migrations
heroku run python init_production_db.py --app your-app-name

# Open app in browser
heroku open --app your-app-name
```

## Development

For local development:

1. **Clone and setup**
   ```bash
   git clone your-repo
   cd arbion-trading-platform
   pip install -r requirements.txt
   ```

2. **Environment variables**
   ```bash
   export FLASK_ENV=development
   export SECRET_KEY=your-secret-key
   export DATABASE_URL=postgresql://localhost/arbion_dev
   ```

3. **Run locally**
   ```bash
   python main.py
   ```

## License

Proprietary - Arbion Trading Platform
© 2025 All rights reserved.
