#!/usr/bin/env python3
"""
Production Database Initialization Script
Initializes the database with required tables and admin user for Heroku deployment
"""

import os
import sys
from werkzeug.security import generate_password_hash

# Add the project root to Python path
sys.path.insert(0, '/app')

try:
    from app import app, db
    from models import User, Settings
    
    def init_production_database():
        """Initialize production database with tables and admin user"""
        
        with app.app_context():
            try:
                # Create all database tables
                print("Creating database tables...")
                db.create_all()
                print("✓ Database tables created successfully")
                
                # Check if admin user already exists
                admin_user = User.query.filter_by(username='admin').first()
                
                if not admin_user:
                    # Create admin user with secure password
                    admin_password = os.environ.get('ADMIN_PASSWORD', 'admin123')
                    
                    admin_user = User(
                        username='admin',
                        email='admin@arbion.ai',
                        password_hash=generate_password_hash(admin_password),
                        is_admin=True,
                        is_master_admin=True,
                        is_active=True
                    )
                    
                    db.session.add(admin_user)
                    db.session.commit()
                    
                    print(f"✓ Admin user created: username='admin', password='{admin_password}'")
                else:
                    print("✓ Admin user already exists")
                
                # Initialize default settings for admin user
                admin_settings = Settings.query.filter_by(user_id=admin_user.id).first()
                
                if not admin_settings:
                    admin_settings = Settings(
                        user_id=admin_user.id,
                        api_provider='schwab',
                        api_key=os.environ.get('SCHWAB_API_KEY', ''),
                        api_secret=os.environ.get('SCHWAB_API_SECRET', ''),
                        is_paper_trading=True,
                        force_simulation_mode=True,
                        max_position_size=1000.0,
                        risk_per_trade=0.02,
                        stop_loss_percentage=0.05,
                        take_profit_percentage=0.10,
                        ai_model_preference='gpt-4o',
                        ai_risk_tolerance='moderate'
                    )
                    
                    db.session.add(admin_settings)
                    db.session.commit()
                    
                    print("✓ Default admin settings created")
                else:
                    print("✓ Admin settings already exist")
                
                print("✓ Production database initialization completed successfully")
                return True
                
            except Exception as e:
                print(f"✗ Error initializing production database: {str(e)}")
                db.session.rollback()
                return False
    
    if __name__ == "__main__":
        print("Starting production database initialization...")
        success = init_production_database()
        
        if success:
            print("Production database ready for deployment")
            sys.exit(0)
        else:
            print("Failed to initialize production database")
            sys.exit(1)
            
except ImportError as e:
    print(f"Import error: {str(e)}")
    print("Skipping database initialization - will be handled by application startup")
    sys.exit(0)
except Exception as e:
    print(f"Unexpected error: {str(e)}")
    sys.exit(1)