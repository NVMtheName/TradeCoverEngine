# Arbion Trading Platform - Heroku Deployment

## Deployment Instructions

1. **Prerequisites:**
   - Heroku CLI installed
   - Git repository initialized

2. **Deploy to Heroku:**
   ```bash
   # Login to Heroku
   heroku login
   
   # Create new Heroku app
   heroku create your-app-name
   
   # Add PostgreSQL addon
   heroku addons:create heroku-postgresql:mini
   
   # Set environment variables
   heroku config:set FLASK_ENV=production
   heroku config:set SECRET_KEY=$(openssl rand -base64 32)
   heroku config:set SESSION_SECRET=$(openssl rand -base64 32)
   
   # Optional: Add API keys
   heroku config:set OPENAI_API_KEY=your_openai_key
   heroku config:set SCHWAB_API_KEY=your_schwab_client_id
   heroku config:set SCHWAB_API_SECRET=your_schwab_client_secret
   
   # Deploy
   git add .
   git commit -m "Deploy Arbion to Heroku"
   git push heroku main
   ```

3. **Post-Deployment:**
   - Admin login: username='admin', password='admin123'
   - Configure Schwab API credentials in Settings
   - Register OAuth callback URL with Schwab Developer Portal

## Features Included:
- Complete schwab-py library integration
- Popup OAuth authentication flow
- AI-powered trading analysis
- Multi-user support with admin controls
- Comprehensive trading strategies
- Real-time market data integration
- Custom domain support (arbion.ai)

## Architecture:
- Flask web framework with SQLAlchemy ORM
- PostgreSQL database
- Gunicorn WSGI server
- Bootstrap responsive UI
- OpenAI GPT integration
- Schwab API integration via schwab-py

## Security:
- HTTPS enforcement
- CSRF protection
- Secure session management
- Environment-based configuration
- OAuth2 authentication flow
