#!/usr/bin/env python3

"""
Schwab Authentication Manager
Comprehensive implementation following schwab-py documentation patterns
"""

import os
import json
import logging
import asyncio
from pathlib import Path
from typing import Optional, Dict, Any
from datetime import datetime, timedelta

import schwab
from schwab.auth import easy_client, client_from_token_file, client_from_login_flow

logger = logging.getLogger(__name__)

class SchwabAuthManager:
    """
    Advanced Schwab authentication manager implementing all schwab-py auth patterns
    Supports: easy_client, token-based auth, login flow, and token refresh
    """
    
    def __init__(self, api_key: str, app_secret: str, callback_url: str = None):
        """
        Initialize Schwab authentication manager
        
        Args:
            api_key: Schwab API key (client ID)
            app_secret: Schwab app secret (client secret)
            callback_url: OAuth callback URL
        """
        self.api_key = api_key
        self.app_secret = app_secret
        self.callback_url = callback_url or "https://127.0.0.1:8182"
        self.production_callback = "https://trading-botv1-82994aa43254.herokuapp.com/oauth/callback"
        
        # Token storage paths
        self.token_dir = Path("/tmp/schwab_tokens")
        self.token_dir.mkdir(exist_ok=True)
        self.token_path = self.token_dir / "schwab_tokens.json"
        
        self.client = None
        self.is_authenticated = False
        
        logger.info(f"Initialized Schwab auth manager with API key: {api_key[:8] if api_key else 'None'}...")
    
    def authenticate_easy_client(self) -> bool:
        """
        Authenticate using schwab-py easy_client method
        This is the simplest approach for first-time setup
        """
        try:
            logger.info("Attempting easy_client authentication...")
            
            self.client = easy_client(
                api_key=self.api_key,
                app_secret=self.app_secret,
                callback_url=self.callback_url,
                token_path=str(self.token_path)
            )
            
            if self.client:
                self.is_authenticated = True
                logger.info("Easy client authentication successful")
                return self._test_connection()
            
            return False
            
        except Exception as e:
            logger.error(f"Easy client authentication failed: {str(e)}")
            return False
    
    def authenticate_from_tokens(self) -> bool:
        """
        Authenticate using existing token file
        This is the fastest method for subsequent authentications
        """
        try:
            if not self.token_path.exists():
                logger.warning("No token file found for token-based authentication")
                return False
            
            logger.info("Attempting token-based authentication...")
            
            self.client = client_from_token_file(
                token_path=str(self.token_path),
                api_key=self.api_key,
                app_secret=self.app_secret
            )
            
            if self.client:
                self.is_authenticated = True
                logger.info("Token-based authentication successful")
                return self._test_connection()
            
            return False
            
        except Exception as e:
            logger.error(f"Token-based authentication failed: {str(e)}")
            return False
    
    def authenticate_login_flow(self) -> str:
        """
        Generate authentication URL for manual login flow
        Returns the URL that users can visit to authorize the application
        """
        try:
            logger.info("Generating direct OAuth authentication URL...")
            
            # Generate OAuth URL directly without interactive flow
            import urllib.parse
            
            auth_params = {
                'response_type': 'code',
                'client_id': self.api_key,
                'redirect_uri': self.callback_url,
                'scope': 'api',
                'state': 'schwab_oauth_state'
            }
            
            auth_url = f"https://api.schwabapi.com/v1/oauth/authorize?{urllib.parse.urlencode(auth_params)}"
            
            logger.info("Direct OAuth URL generated successfully")
            return auth_url
            
        except Exception as e:
            logger.error(f"OAuth URL generation failed: {str(e)}")
            return ""
    
    def authenticate_auto(self) -> bool:
        """
        Automatic authentication using the best available method
        Tries token-based first, then falls back to easy_client
        """
        logger.info("Starting automatic authentication...")
        
        # Try token-based authentication first (fastest)
        if self.authenticate_from_tokens():
            logger.info("Automatic authentication: token-based success")
            return True
        
        # Fall back to easy_client authentication
        if self.authenticate_easy_client():
            logger.info("Automatic authentication: easy_client success")
            return True
        
        logger.warning("Automatic authentication failed with all methods")
        return False
    
    def refresh_tokens(self) -> bool:
        """
        Refresh authentication tokens if they're expired
        """
        try:
            if not self.client:
                logger.error("No client available for token refresh")
                return False
            
            logger.info("Refreshing authentication tokens...")
            
            # The schwab-py library handles token refresh automatically
            # We just need to make a test call to trigger it
            response = self.client.get_user_preferences()
            
            if response.status_code == 200:
                logger.info("Token refresh successful")
                return True
            else:
                logger.error(f"Token refresh failed: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Token refresh error: {str(e)}")
            return False
    
    def get_token_info(self) -> Dict[str, Any]:
        """
        Get information about current tokens
        """
        try:
            if not self.token_path.exists():
                return {"status": "no_tokens", "path": str(self.token_path)}
            
            with open(self.token_path, 'r') as f:
                token_data = json.load(f)
            
            return {
                "status": "tokens_exist",
                "path": str(self.token_path),
                "creation_time": token_data.get("creation_timestamp"),
                "has_access_token": "access_token" in token_data,
                "has_refresh_token": "refresh_token" in token_data
            }
            
        except Exception as e:
            logger.error(f"Error reading token info: {str(e)}")
            return {"status": "error", "error": str(e)}
    
    def clear_tokens(self) -> bool:
        """
        Clear stored authentication tokens
        """
        try:
            if self.token_path.exists():
                self.token_path.unlink()
                logger.info("Authentication tokens cleared")
            
            self.client = None
            self.is_authenticated = False
            return True
            
        except Exception as e:
            logger.error(f"Error clearing tokens: {str(e)}")
            return False
    
    def get_client(self):
        """
        Get the authenticated Schwab client
        """
        return self.client if self.is_authenticated else None
    
    def is_client_ready(self) -> bool:
        """
        Check if client is authenticated and ready for API calls
        """
        return self.is_authenticated and self.client is not None
    
    def _test_connection(self) -> bool:
        """
        Test the API connection to verify authentication
        """
        try:
            if not self.client:
                return False
            
            response = self.client.get_user_preferences()
            
            if response.status_code == 200:
                logger.info("API connection test successful")
                return True
            else:
                logger.error(f"API connection test failed: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"API connection test error: {str(e)}")
            return False
    
    def get_account_info(self) -> Optional[Dict[str, Any]]:
        """
        Get account information using authenticated client
        """
        try:
            if not self.is_client_ready():
                logger.error("Client not authenticated for account info")
                return None
            
            response = self.client.get_accounts()
            
            if response.status_code == 200:
                accounts = response.json()
                return accounts
            else:
                logger.error(f"Failed to get account info: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting account info: {str(e)}")
            return None
    
    def get_quotes(self, symbols: list) -> Optional[Dict[str, Any]]:
        """
        Get market quotes for symbols
        """
        try:
            if not self.is_client_ready():
                logger.error("Client not authenticated for quotes")
                return None
            
            response = self.client.get_quotes(symbols)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get quotes: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting quotes: {str(e)}")
            return None
    
    def get_authentication_status(self) -> Dict[str, Any]:
        """
        Get comprehensive authentication status
        """
        token_info = self.get_token_info()
        
        return {
            "is_authenticated": self.is_authenticated,
            "has_client": self.client is not None,
            "api_key": self.api_key[:8] + "..." if self.api_key else "Not set",
            "callback_url": self.callback_url,
            "production_callback": self.production_callback,
            "token_info": token_info,
            "ready_for_trading": self.is_client_ready()
        }