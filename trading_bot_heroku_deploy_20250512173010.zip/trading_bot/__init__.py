"""
Trading Bot Package

This package contains the core components for the automated trading bot
that analyzes stocks and executes covered call strategies.
"""

__version__ = '0.1.0'
