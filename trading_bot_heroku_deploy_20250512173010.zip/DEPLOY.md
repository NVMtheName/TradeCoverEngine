# Super Quick Deployment Guide

## One-Click Deployment:

1. Extract all files from this zip package
2. Double-click:
   - `deploy_to_heroku.bat` (on Windows)
   - `deploy_to_heroku.sh` (on Mac/Linux)
3. Follow the on-screen prompts

That's it! The script will handle everything else for you.

## What the Script Does:

1. Checks if Heroku CLI is installed (guides you to install if needed)
2. Logs you into Heroku
3. Creates your app 
4. Sets up PostgreSQL database
5. Initializes Git repository
6. Deploys the application
7. Runs database migrations
8. Opens your app in a browser

## After Deployment:

Set your API keys:
```
heroku config:set SCHWAB_API_KEY=your_key_here
heroku config:set SCHWAB_API_SECRET=your_secret_here
heroku config:set OPENAI_API_KEY=your_openai_key_here
```

For detailed instructions, see README_HEROKU.md
