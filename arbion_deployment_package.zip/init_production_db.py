#!/usr/bin/env python3
"""
Production database initialization script for Arbion Trading Platform
This script ensures the admin user exists in the production database
"""
import os
import sys
from werkzeug.security import generate_password_hash

# Add the current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

def init_production_database():
    """Initialize production database with admin user"""
    try:
        from app import app, db
        from models import User, Settings
        
        with app.app_context():
            # Create all tables
            db.create_all()
            
            # Check if admin user exists
            admin_user = User.query.filter_by(username='admin').first()
            
            if not admin_user:
                # Create admin user
                admin_user = User(
                    username='admin',
                    email='admin@arbion.ai',
                    password_hash=generate_password_hash('admin123')
                )
                db.session.add(admin_user)
                db.session.commit()
                print("✅ Admin user created successfully")
            else:
                print("✅ Admin user already exists")
            
            # Check if admin settings exist
            admin_settings = Settings.query.filter_by(user_id=admin_user.id).first()
            
            if not admin_settings:
                # Create default admin settings
                admin_settings = Settings(
                    user_id=admin_user.id,
                    api_provider='schwab',
                    schwab_client_id=os.environ.get('SCHWAB_API_KEY', ''),
                    schwab_client_secret=os.environ.get('SCHWAB_API_SECRET', ''),
                    paper_trading=True,
                    max_position_size=10000.0,
                    risk_level='moderate',
                    ai_enabled=True,
                    ai_model='gpt-4o'
                )
                db.session.add(admin_settings)
                db.session.commit()
                print("✅ Admin settings created successfully")
            else:
                print("✅ Admin settings already exist")
                
            print("✅ Production database initialized successfully")
            return True
            
    except Exception as e:
        print(f"❌ Error initializing production database: {e}")
        return False

if __name__ == "__main__":
    success = init_production_database()
    sys.exit(0 if success else 1)