#!/usr/bin/env python3

"""
Schwab API Connector using the official schwab-py library
This provides robust OAuth authentication and API access
"""

import os
import logging
import json
from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List

import schwab
from schwab.auth import easy_client

logger = logging.getLogger(__name__)

class SchwabPyConnector:
    """Modern Schwab API connector using schwab-py library"""
    
    def __init__(self, app_key: str, app_secret: str, callback_url: str = None):
        """
        Initialize Schwab API connector
        
        Args:
            app_key: Schwab API application key (client ID)
            app_secret: Schwab API application secret
            callback_url: OAuth callback URL for your application
        """
        self.app_key = app_key
        self.app_secret = app_secret
        self.callback_url = callback_url or "https://trading-botv1-82994aa43254.herokuapp.com/oauth/callback"
        self.client = None
        self.token_path = "/tmp/schwab_tokens.json"
        
        logger.info(f"Initialized Schwab connector with app key: {app_key[:8] if app_key else 'None'}...")
        
    def authenticate(self, interactive: bool = False) -> bool:
        """
        Authenticate with Schwab API using OAuth
        
        Args:
            interactive: Whether to use interactive authentication
            
        Returns:
            bool: True if authentication successful
        """
        try:
            if interactive:
                # Interactive authentication for first-time setup
                self.client = easy_client(
                    api_key=self.app_key,
                    app_secret=self.app_secret,
                    callback_url=self.callback_url,
                    token_path=self.token_path
                )
            else:
                # Try to load existing tokens
                if os.path.exists(self.token_path):
                    self.client = schwab.auth.client_from_token_file(
                        token_path=self.token_path,
                        api_key=self.app_key,
                        app_secret=self.app_secret
                    )
                else:
                    logger.warning("No token file found. Interactive authentication required.")
                    return False
            
            # Test the connection
            response = self.client.get_user_preferences()
            if response.status_code == 200:
                logger.info("Schwab API authentication successful")
                return True
            else:
                logger.error(f"Authentication test failed: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Authentication failed: {str(e)}")
            return False
    
    def get_account_info(self) -> Optional[Dict[str, Any]]:
        """Get account information"""
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
                
            response = self.client.get_accounts()
            if response.status_code == 200:
                accounts = response.json()
                if accounts:
                    # Return the first account
                    account = accounts[0]
                    return {
                        'account_id': account['securitiesAccount']['accountId'],
                        'account_type': account['securitiesAccount']['type'],
                        'current_balances': account['securitiesAccount']['currentBalances'],
                        'initial_balances': account['securitiesAccount']['initialBalances'],
                        'positions': account['securitiesAccount'].get('positions', [])
                    }
            else:
                logger.error(f"Failed to get accounts: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting account info: {str(e)}")
            return None
    
    def get_quotes(self, symbols: List[str]) -> Optional[Dict[str, Any]]:
        """
        Get real-time quotes for symbols
        
        Args:
            symbols: List of stock symbols
            
        Returns:
            Dict containing quote data for each symbol
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
                
            response = self.client.get_quotes(symbols)
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get quotes: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting quotes: {str(e)}")
            return None
    
    def get_option_chain(self, symbol: str, expiry_date: str = None) -> Optional[Dict[str, Any]]:
        """
        Get options chain for a symbol
        
        Args:
            symbol: Stock symbol
            expiry_date: Option expiration date (YYYY-MM-DD)
            
        Returns:
            Options chain data
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
            
            # Build the options chain request
            request = self.client.get_option_chain(symbol)
            
            if expiry_date:
                # Add expiration date filter if provided
                request = request.expiration_date(expiry_date)
            
            response = request.build()
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get option chain: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting option chain: {str(e)}")
            return None
    
    def place_order(self, account_id: str, order_spec: Dict[str, Any]) -> Optional[str]:
        """
        Place a trading order
        
        Args:
            account_id: Account ID to place order in
            order_spec: Order specification dictionary
            
        Returns:
            Order ID if successful, None otherwise
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
            
            # Create basic order structure for schwab-py
            order = {
                "orderType": "MARKET",
                "session": "NORMAL", 
                "duration": "DAY",
                "orderLegCollection": []
            }
            
            if order_spec.get('order_type') == 'BUY_TO_OPEN':
                # Buy equity order
                order["orderLegCollection"].append({
                    "instruction": "BUY",
                    "quantity": order_spec['quantity'],
                    "instrument": {
                        "symbol": order_spec['symbol'],
                        "assetType": "EQUITY"
                    }
                })
            
            elif order_spec.get('order_type') == 'SELL_TO_OPEN':
                # Sell option order
                order["orderType"] = "LIMIT"
                order["price"] = order_spec.get('limit_price', 1.0)
                order["orderLegCollection"].append({
                    "instruction": "SELL_TO_OPEN",
                    "quantity": order_spec['quantity'],
                    "instrument": {
                        "symbol": order_spec['option_symbol'],
                        "assetType": "OPTION"
                    }
                })
            
            else:
                logger.error(f"Unsupported order type: {order_spec.get('order_type')}")
                return None
            
            # Place the order using direct API call
            response = self.client.place_order(account_id, order)
            
            if response.status_code == 201:
                # Extract order ID from response headers
                location = response.headers.get('Location', '')
                order_id = location.split('/')[-1] if location else None
                logger.info(f"Order placed successfully. Order ID: {order_id}")
                return order_id
            else:
                logger.error(f"Failed to place order: {response.status_code} - {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error placing order: {str(e)}")
            return None
    
    def get_orders(self, account_hash: str, days_back: int = 30) -> Optional[List[Dict[str, Any]]]:
        """
        Get recent orders for an account
        
        Args:
            account_hash: Account hash (encrypted account number)
            days_back: Number of days to look back
            
        Returns:
            List of order data
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
            
            from_date = datetime.now() - timedelta(days=days_back)
            to_date = datetime.now()
            
            response = self.client.get_orders_for_account(
                account_hash,
                from_entered_datetime=from_date,
                to_entered_datetime=to_date
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get orders: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting orders: {str(e)}")
            return None
    
    def get_positions(self, account_id: str) -> Optional[List[Dict[str, Any]]]:
        """
        Get current positions for an account
        
        Args:
            account_id: Account ID
            
        Returns:
            List of position data
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
            
            response = self.client.get_account(account_id, fields=['positions'])
            
            if response.status_code == 200:
                account_data = response.json()
                return account_data['securitiesAccount'].get('positions', [])
            else:
                logger.error(f"Failed to get positions: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting positions: {str(e)}")
            return None
    
    def cancel_order(self, account_id: str, order_id: str) -> bool:
        """
        Cancel an existing order
        
        Args:
            account_id: Account ID
            order_id: Order ID to cancel
            
        Returns:
            True if successful, False otherwise
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return False
            
            response = self.client.cancel_order(account_id, order_id)
            
            if response.status_code == 200:
                logger.info(f"Order {order_id} cancelled successfully")
                return True
            else:
                logger.error(f"Failed to cancel order: {response.status_code}")
                return False
                
        except Exception as e:
            logger.error(f"Error cancelling order: {str(e)}")
            return False
    
    def get_market_hours(self, market: str = 'EQUITY') -> Optional[Dict[str, Any]]:
        """
        Get market hours information
        
        Args:
            market: Market type (EQUITY, OPTION, etc.)
            
        Returns:
            Market hours data
        """
        try:
            if not self.client:
                logger.error("Not authenticated")
                return None
            
            today = datetime.now().strftime('%Y-%m-%d')
            response = self.client.get_market_hours([market], today)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get market hours: {response.status_code}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting market hours: {str(e)}")
            return None
    
    def is_connected(self) -> bool:
        """Check if the client is properly connected"""
        return self.client is not None
    
    def get_authentication_url(self) -> str:
        """
        Get the OAuth authentication URL for manual setup
        
        Returns:
            Authentication URL string
        """
        auth_url = schwab.auth.client_from_login_flow(
            self.app_key, 
            self.app_secret, 
            self.callback_url,
            self.token_path
        )
        return auth_url