# Trading Bot - Heroku Deployment

This package contains a ready-to-deploy version of the Trading Bot application for Heroku.

## Deployment Instructions

1. **Install the Heroku CLI** (if you haven't already):
   Follow instructions at https://devcenter.heroku.com/articles/heroku-cli

2. **Log in to Heroku**:
   ```
   heroku login
   ```

3. **Create a new Heroku app** (or use an existing one):
   ```
   heroku create your-app-name
   ```

4. **Add a PostgreSQL database**:
   ```
   heroku addons:create heroku-postgresql:mini
   ```

5. **Configure environment variables**:
   ```
   heroku config:set FLASK_ENV=production
   heroku config:set SCHWAB_API_KEY=your_key_here
   heroku config:set SCHWAB_API_SECRET=your_secret_here
   ```

6. **Deploy the application**:
   ```
   git push heroku main
   ```

7. **Initialize the database**:
   ```
   heroku run python migrate_db.py
   ```

8. **Visit your application**:
   ```
   heroku open
   ```

## Troubleshooting

- **Database issues**: 
  Run `heroku pg:info` to check database status.
  
- **Application errors**: 
  Check logs with `heroku logs --tail`

- **Deployment failures**: 
  Ensure you have the correct buildpacks with `heroku buildpacks`
  
## Running Tests

This application includes a TAP testing framework. To run tests in Heroku CI:

1. Enable Heroku CI for your application
2. Push changes to GitHub (if using GitHub integration)
3. Tests will automatically run using the configuration in app.ci

To run tests locally:
```
python run_tap_tests.py
```

## Additional Resources

- Heroku Python Support: https://devcenter.heroku.com/articles/python-support
- Heroku PostgreSQL: https://devcenter.heroku.com/articles/heroku-postgresql
