# Quick Deployment Guide

## One-Click Deployment:

1. Extract all files from this zip package
2. Install Heroku CLI
3. Run: `heroku login`
4. Run: `heroku create your-app-name`
5. Run: `heroku addons:create heroku-postgresql:mini`
6. Run: `git init && git add . && git commit -m "Initial commit"`
7. Run: `git push heroku main`
8. Run: `heroku run python migrate_db.py`
9. Run: `heroku open`

## Configuring API Keys:

After deployment, set your API keys:
```
heroku config:set SCHWAB_API_KEY=your_key_here
heroku config:set SCHWAB_API_SECRET=your_secret_here
heroku config:set OPENAI_API_KEY=your_openai_key_here
```

For detailed instructions, see README_HEROKU.md
